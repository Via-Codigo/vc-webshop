# vc-webshop

## Pagina web

1. Para que quieren tener una web

Promocionar el taller web donde los ex alumnos trabajan para clientes

2. ¿ Qué impresión esperas que se lleven del servicio a
Desarrollar?

Es una web bien construida y con un fin social importante

3. ¿ Qué es lo que deseas que un usuario nuevo haga al visitar
la página web por primera vez?

Entender que ayuda a los viacoders

4. ¿ Cuales son las acciones secundarias que los usuarios
realizarán cuando utilicen este servicio o producto?

Informarse sobre como contactarnos para pedir un proyecto

5. ¿Que mensaje expresarías a través de la pagina web?

Hacemos páginas web que ayudan a la sociedad


## Información sobre los usuarios

1. ¿ Quiénes utilizarán el producto o servicio que desarrollamos
para ti? (Enumerar en orden de importancia los tipos de
usuarios que entrarán a su web.)

Pequeños clientes o empresas que buscan webs pequeñas a un precio cómodo

2. ¿ Qué es lo que esperas que realicen tus diferentes usuarios
con el productos o servicio que te brindaremos? ( puesto y
categoría de usuario)

Informarse

3. ¿ Donde anticipa que los usuarios se encuentren cuando
intenten hacer las tareas antes mencionadas? ( en su casa de
viaje, etc.) ( puesto, categoría de usuario, lugar de conexión)

Celular primero computadora después, osea, caminando o en la oficina

4. ¿ Qué tipos de dispositivos espera que se utilicen para acceder
a los servicios o productos que desarrollaremos? ( puesto,
dispositivo preferido, categoría de usuario)

Celular

5. ¿ Qué tanto conocimiento de informática considera que
tendrán tus usuarios? ( eventual, inexperto, social, avanzado,
experto)

Basico hasta avanzado

6. ¿ Qué percepción deseas que tengan tus usuarios cuando
accedan a los productos que desarrollaremos? ( rápida,
completa, compleja,etc.)

Que fácil de leer que bonito (sin errores)

7. ¿ Qué es lo más importante para ellos? ¿ por que
específicamente utilizarías este servicio?

Porque te da ganas de ayudar a los viacoders



## Enumerar las secciones de la página web

#### Inicio

- Imagen grande del salón encima
- Frase poderosa sobre la imagen con botón que lleva a la acción
- Link a logos de medios de prensa debajo de la imagen (como last mile)
- Sección con imágenes similar a la web de ejemplo donde se explica como trabajamos
- Sección de testimoniales de clientes
- Sección de cajas con imágenes donde se explica por que deben ayudar (como last mile)
- Sección de portafolio  webs realizadas para clientes



#### Contrátanos

- Sección con imagen grande del salón arriba
- Debajo formulario de contacto con los sgtes campos:
  - Nombre completo
  - Email
  - Empresa
  - Cargo
  - Textarea (mensaje)
- Preguntas Frecuentes (FAQ)
  - Sección con una imágen del salón arriba 
  - debajo un listado de preguntas con sus respuestas

#### Portafolio

- Sección con imágen grande arriba 
- Listado de websites que se han trabajado, con imágen, título, técnica usada y párrafo descriptivo. Cada uno lleva a su propia página de proyecto
  
#### Proyecto

-  Título, logo de la marca, foto de la web y un largo texto con todos los tipos de letra (strong, em, i, UL, OL, blockquote) en que se explica como se trabajó con esa empresa






